<?php

namespace Epmnzava\Tigosecure;

class Tigosecure
{
    // Build your next great package.
}
